package com.example.vechicleapplication;

import java.io.Serializable;

public class Vechicle implements Serializable {


    private String company;
    private  String chasisno;
    private String color;
    private String price;

    public Vechicle() {

    }

    public Vechicle(String company, String chasisno, String color, String price) {
        this.company = company;
        this.chasisno = chasisno;
        this.color = color;
        this.price = price;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getChasisno() {
        return chasisno;
    }

    public void setChasisno(String chasisno) {
        this.chasisno = chasisno;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Vechicle{" +
                "company='" + company + '\'' +
                ", chasisno='" + chasisno + '\'' +
                ", color='" + color + '\'' +
                ", price='" + price + '\'' +
                '}';
    }
}
