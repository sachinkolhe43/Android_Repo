package com.example.vechicleapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class VechicleDetailsActivity extends AppCompatActivity {

    TextView textCompany,textChasisno,textColor,textPrice;
    Vechicle vechicle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vechicle_details);

        textCompany = findViewById(R.id.textCompany);
        textChasisno = findViewById(R.id.textChasisno);
        textColor = findViewById(R.id.textColor);
        textPrice = findViewById(R.id.textPrice);

        vechicle = (Vechicle) getIntent().getSerializableExtra("vechicle");

    }

    public void back(View view){
        finish();
    }
}
