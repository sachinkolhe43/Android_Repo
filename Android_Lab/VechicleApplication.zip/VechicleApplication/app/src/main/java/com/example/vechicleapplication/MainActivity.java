package com.example.vechicleapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;
    RecyclerView recyclerView;
    VechicleListAdapter vechicleListAdapter;
    List<Vechicle> vechicleList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vechicleList=new ArrayList<>();
        toolbar = findViewById(R.id.toolbar);
        recyclerView = findViewById(R.id.recyclerView);
        setSupportActionBar(toolbar);

        vechicleListAdapter = new VechicleListAdapter(this,vechicleList);
        recyclerView.setAdapter(vechicleListAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1));

        getAllVechicle();
    }

    private void getAllVechicle() {

        VechcileDBHelper dbHelper = new VechcileDBHelper(this);
        dbHelper.getListVechicle(vechicleList);
        vechicleListAdapter.notifyDataSetChanged();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.logout_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        startActivity(new Intent(this, AddVechicleActivity.class));

        finish();
        return super.onOptionsItemSelected(item);
    }
}