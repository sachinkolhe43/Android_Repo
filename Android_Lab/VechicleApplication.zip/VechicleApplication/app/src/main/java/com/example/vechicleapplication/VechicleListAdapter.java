package com.example.vechicleapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class VechicleListAdapter extends RecyclerView.Adapter<VechicleListAdapter.MyViewHolder> {
    Context context;
    List<Vechicle> vechicleList;

    public VechicleListAdapter(Context context, List<Vechicle> vechicleList) {
        this.context = context;
        this.vechicleList = vechicleList;
    }

    @NonNull
    @Override
    public VechicleListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.vechicle_list,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VechicleListAdapter.MyViewHolder holder, int position) {
        Vechicle vechicle = vechicleList.get(position);
        holder.textCompany.setText(vechicle.getCompany());
        holder.textChasisno.setText(vechicle.getChasisno());

    }

    @Override
    public int getItemCount() {
        return vechicleList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView textChasisno,textCompany;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textCompany = itemView.findViewById(R.id.textCompany);
            textChasisno = itemView.findViewById(R.id.textChasisno);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, VechicleDetailsActivity.class);
                    intent.putExtra("vechicle", vechicleList.get(getAdapterPosition()));
                    context.startActivity(intent);
                }
            });
        }
    }
}
