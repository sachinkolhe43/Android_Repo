package com.example.vechicleapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.List;

public class VechcileDBHelper extends SQLiteOpenHelper {
    public VechcileDBHelper(@Nullable Context context) {

        super(context, "new1_db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String sql = "CREATE TABLE vechicle(company TEXT,chasisno TEXT,color TEXT,Price TEXT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertVechcile(Vechicle vechicle) {

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();


        values.put("company", vechicle.getCompany());
        values.put("chasisno", vechicle.getChasisno());
        values.put("color", vechicle.getColor());
        values.put("Price", vechicle.getPrice());

        db.insert("vechicle", null, values);
    }


    public void getListVechicle(List<Vechicle> vechicleList) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("vechicle", null, null, null, null, null, null);

        while (cursor.moveToNext()) {


            String company = cursor.getString(0);
            String chasisno = cursor.getString(1);
            String color = cursor.getString(2);
            String Price = cursor.getString(3);


            Vechicle employee = new Vechicle(company, chasisno, color, Price);

            vechicleList.add(employee);
        }

    }
}
