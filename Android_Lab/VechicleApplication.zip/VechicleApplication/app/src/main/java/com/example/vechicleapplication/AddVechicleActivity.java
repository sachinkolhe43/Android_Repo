package com.example.vechicleapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddVechicleActivity extends AppCompatActivity {

    EditText editCompany, editChasisno, editColor, editPrice;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vechicle);

        editCompany = findViewById(R.id.editCompany);
        editChasisno = findViewById(R.id.editChasisno);
        editColor = findViewById(R.id.editColor);
        editPrice = findViewById(R.id.editPrice);
    }

    public void register(View view) {


        String company = editCompany.getText().toString();
        String chasisno = editChasisno.getText().toString();
        String color = editColor.getText().toString();
        String price = editPrice.getText().toString();

            new VechcileDBHelper(this).insertVechcile(new Vechicle(company, chasisno, color, price));
            Toast.makeText(this, "Adding Successful", Toast.LENGTH_SHORT).show();



    }

    public void cancel(View view) {
        finish();
    }
}