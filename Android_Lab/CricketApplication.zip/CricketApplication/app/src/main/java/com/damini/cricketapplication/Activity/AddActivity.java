package com.damini.cricketapplication.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.damini.cricketapplication.DB.CricketerDBhelper;
import com.damini.cricketapplication.Entity.Cricketer;
import com.damini.cricketapplication.R;

import java.util.ArrayList;
import java.util.List;

public class AddActivity extends AppCompatActivity {
    EditText editTextName,editTextAge,editTextRating,editTextAddress;
    Button btnSave,btnCancel;
    List<Cricketer> cricketerList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        editTextName = findViewById(R.id.editTextName);
        editTextAge = findViewById(R.id.editTextAge);
        editTextRating = findViewById(R.id.editTextRating);
        editTextAddress = findViewById(R.id.editTextAddress);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        cricketerList = new ArrayList<>();

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AddActivity.this, "save", Toast.LENGTH_SHORT).show();
                String name = editTextName.getText().toString();
                int age = Integer.parseInt(editTextAge.getText().toString());
                int ratings = Integer.parseInt(editTextRating.getText().toString());
                String address = editTextAddress.getText().toString();

                CricketerDBhelper dBhelper = new CricketerDBhelper(AddActivity.this);
                dBhelper.addCricketer(name,age,ratings,address);

                getData();

            }

            private void getData() {
                cricketerList.clear();
                CricketerDBhelper dBhelper = new CricketerDBhelper(AddActivity.this);
                dBhelper.fetchCrickter(cricketerList);
            }
        });


        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}