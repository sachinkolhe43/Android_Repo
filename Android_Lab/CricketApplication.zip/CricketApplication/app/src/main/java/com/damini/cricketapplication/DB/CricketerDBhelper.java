package com.damini.cricketapplication.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.damini.cricketapplication.Activity.AddActivity;
import com.damini.cricketapplication.Entity.Cricketer;

import java.util.List;

public class CricketerDBhelper extends SQLiteOpenHelper {


    public CricketerDBhelper(@Nullable Context context) {
        super(context, "cricketer_db", null, 1);
    }

    public CricketerDBhelper(AddActivity context) {
        super(context, "cricketer_db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE cricketer(name TEXT, age INT, ratings  INT, address TEXT)";
        db.execSQL(sql);
        Log.e("cricketerDBHelper","OnCreate()");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void addCricketer(String name, int age, int ratings, String address) {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name",name);
        values.put("age",age);
        values.put("ratings",ratings);
        values.put("address",address);
        database.insert("cricketer",null,values);
    }

    public void fetchCrickter(List<Cricketer> cricketerList) {
        SQLiteDatabase database = getReadableDatabase();
        Cursor cursor = database.query("cricketer",null,null,null,null,null,null);
        while(cursor.moveToNext()){
            String name = cursor.getString(0);
            int age = cursor.getInt(1);
            int ratings = cursor.getInt(2);
            String address = cursor.getString(3);
            Cricketer cricketer = new Cricketer(name,age,ratings,address);
            cricketerList.add(cricketer);
            Log.e("list",name +","+age +","+ratings+","+address);
        }

    }
}
