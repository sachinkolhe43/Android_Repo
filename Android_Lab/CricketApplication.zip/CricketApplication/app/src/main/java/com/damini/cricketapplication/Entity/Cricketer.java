package com.damini.cricketapplication.Entity;

public class Cricketer {
    private String name ;
    private int age ;
    private int ratings ;
    private String address ;

    public Cricketer() {
    }

    public Cricketer(String name, int age, int ratings, String address) {
        this.name = name;
        this.age = age;
        this.ratings = ratings;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getRatings() {
        return ratings;
    }

    public void setRatings(int ratings) {
        this.ratings = ratings;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return
                "Name : " + name +
                "\nAge : " + age +
                "\nRatings : " + ratings +
                "\nAddress : " + address ;
    }
}
