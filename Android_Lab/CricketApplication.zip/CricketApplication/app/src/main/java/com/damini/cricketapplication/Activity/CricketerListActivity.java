package com.damini.cricketapplication.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.damini.cricketapplication.Adaptor.CrickterListAdaptor;
import com.damini.cricketapplication.DB.CricketerDBhelper;
import com.damini.cricketapplication.Entity.Cricketer;
import com.damini.cricketapplication.R;

import java.util.ArrayList;
import java.util.List;

public class CricketerListActivity extends AppCompatActivity {

    RecyclerView recyclerViewCricketers;
    CrickterListAdaptor crickterListAdaptor;
    List<Cricketer> cricketerList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cricketer_list);

        recyclerViewCricketers = findViewById(R.id.recyclerViewCricketers);
        cricketerList = new ArrayList<>();
        crickterListAdaptor = new CrickterListAdaptor(this,cricketerList);
        recyclerViewCricketers.setAdapter(crickterListAdaptor);
        recyclerViewCricketers.setLayoutManager(new GridLayoutManager(this ,1));
        getDisplayData();
    }

    private void getDisplayData() {
        cricketerList.clear();
        CricketerDBhelper  dBhelper = new CricketerDBhelper(CricketerListActivity.this );
        dBhelper.fetchCrickter(cricketerList);
        crickterListAdaptor.notifyDataSetChanged();
    }
}