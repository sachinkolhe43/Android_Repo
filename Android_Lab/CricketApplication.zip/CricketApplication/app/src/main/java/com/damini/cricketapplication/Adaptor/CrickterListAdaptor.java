package com.damini.cricketapplication.Adaptor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.damini.cricketapplication.Entity.Cricketer;
import com.damini.cricketapplication.R;

import java.util.List;

public class CrickterListAdaptor extends RecyclerView.Adapter<CrickterListAdaptor.MyViewHolder> {
    Context context;
    List<Cricketer> cricketerList;

    public CrickterListAdaptor(Context context, List<Cricketer> cricketerList) {
        this.context = context;
        this.cricketerList = cricketerList;
    }

    @NonNull
    @Override
    public CrickterListAdaptor.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.cricketer_list,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CrickterListAdaptor.MyViewHolder holder, int position) {
        holder.textName.setText(this.cricketerList.get(position).toString());

    }

    @Override
    public int getItemCount() {
        return cricketerList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView textName ;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.textName);
        }
    }
}
