package com.damini.singerapplication.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.damini.singerapplication.DB.SingerDBHelper;
import com.damini.singerapplication.Entity.Singer;
import com.damini.singerapplication.R;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AddActivity extends AppCompatActivity {
    EditText editTextName,editTextAge,editTextCountry,editTextFollowers;
    Button btnSave ,btnCancel ;
    List<Singer> singerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        editTextName = findViewById(R.id.editTextName);
        editTextAge = findViewById(R.id.editTextAge);
        editTextCountry = findViewById(R.id.editTextCountry);
        editTextFollowers = findViewById(R.id.editTextFollowers);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);
        singerList = new ArrayList<>();


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AddActivity.this, "save", Toast.LENGTH_SHORT).show();
                String name = editTextName.getText().toString();
                int age = Integer.parseInt(editTextAge.getText().toString());
                String country = editTextCountry.getText().toString();
                int followers = Integer.parseInt(editTextFollowers.getText().toString());
                getResult();
                SingerDBHelper dbHelper = new SingerDBHelper(AddActivity.this );
                dbHelper.addSinger(name,age,country,followers);
                getSinger();
            }

            private void getResult() {
                Singer singer = new Singer();
                singer.setName(editTextName.getText().toString());
                singer.setAge(Integer.parseInt(editTextAge.getText().toString()));
                singer.setCountry(editTextCountry.getText().toString());
                singer.setFollowers(Integer.parseInt(editTextFollowers.getText().toString()));

                Intent intent = new Intent();
                intent.putExtra("singer",singer);
                setResult(0,intent);
                finish();
            }

            private void getSinger() {
                singerList.clear();
                SingerDBHelper  dbHelper = new SingerDBHelper(AddActivity.this);
                dbHelper.fetchSinger(singerList);
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


}