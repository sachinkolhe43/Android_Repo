package com.damini.singerapplication.Entity;

import java.io.Serializable;

public class Singer implements Serializable {
    private  String name ;
    private int age ;
    private String country ;
    private int followers;

    public Singer() {
    }

    public Singer(String name, int age, String country, int followers) {
        this.name = name;
        this.age = age;
        this.country = country;
        this.followers = followers;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public int getFollowers() {
        return followers;
    }

    public void setFollowers(int followers) {
        this.followers = followers;
    }

    @Override
    public String toString() {
        return
                "Name : " + name +
                "\nAge : " + age ;
    }
}
