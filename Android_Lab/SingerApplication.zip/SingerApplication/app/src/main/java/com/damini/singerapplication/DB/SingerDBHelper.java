package com.damini.singerapplication.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.damini.singerapplication.Entity.Singer;

import java.util.List;

public class SingerDBHelper extends SQLiteOpenHelper {

    public SingerDBHelper(@Nullable Context context) {
        super(context, "singer_db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE singer(name TEXT , age INT , country TEXT , followers INT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void addSinger(String name, int age, String country, int followers) {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name",name);
        values.put("age",age);
        values.put("country",country);
        values.put("followers",followers);
        database.insert("singer",null,values);
    }

    public void fetchSinger(List<Singer> singerList) {
        SQLiteDatabase database = getReadableDatabase();
        Cursor cursor = database.query("singer",null,null,null,null,null,null);
        while(cursor.moveToNext()){
            String name = cursor.getString(0);
            int age = cursor.getInt(1);
            String country = cursor.getString(2);
            int followers = cursor.getInt(3);
            Singer singer = new Singer(name,age,country,followers);
            singerList.add(singer);
            Log.e("list",name +","+age+","+country+","+followers);
        }
    }
}
