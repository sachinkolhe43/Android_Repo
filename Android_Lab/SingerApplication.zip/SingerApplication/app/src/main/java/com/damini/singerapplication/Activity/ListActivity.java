package com.damini.singerapplication.Activity;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityOptionsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.damini.singerapplication.Entity.Singer;
import com.damini.singerapplication.R;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {
    Toolbar toolBar;
    ListView listView ;
    List<Singer> singerList;
    ArrayAdapter arrayAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolBar = findViewById(R.id.toolBar);
        listView = findViewById(R.id.listView);

        setSupportActionBar(toolBar);

        singerList= new ArrayList<>();
        arrayAdapter = new ArrayAdapter<>(this , android.R.layout.simple_list_item_1,singerList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ListActivity.this,DetailActivity.class);
                intent.putExtra("singer",singerList.get(position));
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.add_singer,menu);
        return super.onCreateOptionsMenu(menu);
    }

    ActivityResultLauncher activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult result) {
            Intent intent = result.getData();
            if(intent != null){
                Singer singer = (Singer) intent.getSerializableExtra("singer");
                singerList.add(singer);
                arrayAdapter.notifyDataSetChanged();

            }

        }
    });


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        activityResultLauncher.launch(new Intent(this,AddActivity.class));
        return super.onOptionsItemSelected(item);
    }
}