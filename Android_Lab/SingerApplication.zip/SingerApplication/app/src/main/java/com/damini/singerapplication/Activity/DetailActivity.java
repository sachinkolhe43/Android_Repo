package com.damini.singerapplication.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.damini.singerapplication.Entity.Singer;
import com.damini.singerapplication.R;

public class DetailActivity extends AppCompatActivity {
    TextView textName ,textAge,textCountry,textFollowers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        textName = findViewById(R.id.textName);
        textAge = findViewById(R.id.textAge);
        textCountry = findViewById(R.id.textCountry);
        textFollowers = findViewById(R.id.textFollowers);

        Singer singer = (Singer) getIntent().getSerializableExtra("singer");
        textName.setText("Name : "+singer.getName());
        textAge.setText("Age : "+singer.getAge());
        textCountry.setText("Country : " + singer.getCountry());
        textFollowers.setText("Followers : "+singer.getFollowers());

    }
}